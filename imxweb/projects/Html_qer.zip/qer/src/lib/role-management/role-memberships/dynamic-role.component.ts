/*
 * ONE IDENTITY LLC. PROPRIETARY INFORMATION
 *
 * This software is confidential.  One Identity, LLC. or one of its affiliates or
 * subsidiaries, has supplied this software to you under terms of a
 * license agreement, nondisclosure agreement or both.
 *
 * You may not copy, disclose, or use this software except in accordance with
 * those terms.
 *
 *
 * Copyright 2024 One Identity LLC.
 * ALL RIGHTS RESERVED.
 *
 * ONE IDENTITY LLC. MAKES NO REPRESENTATIONS OR
 * WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR
 * NON-INFRINGEMENT.  ONE IDENTITY LLC. SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE
 * AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

import { ChangeDetectorRef, Component, Input, OnInit } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { EuiLoadingService } from '@elemental-ui/core';
import { PortalDynamicgroup } from '@imx-modules/imx-api-qer';
import { LogOp, SqlExpression, SqlWizardExpression, WriteExtTypedEntity, isExpressionInvalid } from '@imx-modules/imx-qbm-dbts';
import { TranslateService } from '@ngx-translate/core';
import _ from 'lodash';
import { BaseCdr, BaseReadonlyCdr, ColumnDependentReference, ConfirmationService, SqlWizardApiService } from 'qbm';
import { QerApiService } from '../../qer-api-client.service';
import { DataManagementService } from '../data-management.service';
import { DynamicRoleSqlWizardService } from '../dynamicrole-sqlwizard.service';
import { RoleService } from '../role.service';

@Component({
  templateUrl: './dynamic-role.component.html',
  styleUrls: ['./role-sidesheet-tabs.scss', './dynamic-role.component.scss'],
  selector: 'imx-dynamic-group',
  providers: [
    {
      provide: SqlWizardApiService,
      useClass: DynamicRoleSqlWizardService,
    },
  ],
})
export class DynamicRoleComponent implements OnInit {
  constructor(
    formBuilder: UntypedFormBuilder,
    private readonly apiService: QerApiService,
    private readonly roleService: RoleService,
    private dataManagementService: DataManagementService,
    private readonly translator: TranslateService,
    private readonly cdref: ChangeDetectorRef,
    private readonly confirmSvc: ConfirmationService,
    private readonly busyService: EuiLoadingService,
  ) {
    this.formGroup = new UntypedFormGroup({ formArray: formBuilder.array([]) });
  }

  @Input() uidDynamicGroup: string | undefined;

  get formArray(): UntypedFormArray {
    return this.formGroup.get('formArray') as UntypedFormArray;
  }

  public dynamicGroup: PortalDynamicgroup | undefined;

  public sqlExpression: SqlWizardExpression | undefined;
  public lastSavedExpression: SqlExpression | undefined;
  public lastSavedCDRs: any[];

  public showHelperAlert = true;
  public exprHasntChanged = true;
  public cdrsHaventChanged = true;
  public readonly formGroup: UntypedFormGroup;
  public cdrList: ColumnDependentReference[] = [];
  public busy = true;
  public canEdit: boolean;

  public async ngOnInit(): Promise<void> {
    this.canEdit = this.roleService.canEdit;
    if (!this.canEdit) {
      this.LdsNoDynamicRole = '#LDS#Currently, no identities automatically become members through a dynamic role.';
    }
    await this.loadDynamicRole();
    this.resetState();
  }

  public resetState(): void {
    this.lastSavedExpression = _.cloneDeep(this.sqlExpression?.Expression);
    this.lastSavedCDRs = [];
    this.cdrList.map((cdr) => {
      this.lastSavedCDRs.push(cdr.column.GetValue());
    });
    this.exprHasntChanged = true;
    this.cdrsHaventChanged = true;
    this.formGroup.markAsPristine();
  }

  public async save(): Promise<void> {
    try {
      this.busyService.show();
      if (this.dynamicGroup) {
        if (!this.sqlExpression?.IsUnsupported) {
          this.dynamicGroup.extendedData = { Filters: this.sqlExpression?.Expression == null ? [] : [this.sqlExpression.Expression] };
        }
        await this.dynamicGroup.GetEntity().Commit(true);
      } else {
        const e = <WriteExtTypedEntity<{ NewDynamicRole: SqlExpression | undefined }>>this.dataManagementService.entityInteractive;
        e.extendedData = { NewDynamicRole: this.sqlExpression?.Expression };
        await e.GetEntity().Commit(true);
        this.uidDynamicGroup = e.GetEntity().GetColumn('UID_DynamicGroup').GetValue();
        await this.loadDynamicRole(false);
      }
    } finally {
      await this.dataManagementService.setInteractive();
      this.resetState();
      this.busyService.hide();
      this.dataManagementService.autoMembershipDirty(false);
    }
  }

  public async createDynamic(): Promise<void> {
    this.sqlExpression = {
      Expression: {
        Expressions: [],
        LogOperator: LogOp.AND,
        Negate: false,
      },
    };
    this.cdref.detectChanges();
    this.dataManagementService.autoMembershipDirty(true);
  }

  public async deleteDynamic(): Promise<void> {
    const title = await this.translator.get('#LDS#Heading Delete Dynamic Role').toPromise();
    // If there is no active dynamic role, no one will actually be removed
    var warningKey = this.uidDynamicGroup
      ? '#LDS#All members assigned by the dynamic role will be removed. Are you sure you want to delete the dynamic role?'
      : '#LDS#Are you sure you want to delete the dynamic role?';
    const message = await this.translator.get(warningKey).toPromise();

    const result = await this.confirmSvc.confirm({
      ShowYesNo: true,
      Title: title,
      Message: message,
    });
    if (!result) return;

    try {
      this.busyService.show();

      if (this.uidDynamicGroup) {
        await this.apiService.v2Client.portal_dynamicgroup_delete(this.uidDynamicGroup);
        this.uidDynamicGroup = undefined;
      }
      this.dynamicGroup = undefined;
      this.sqlExpression = undefined;
      this.dataManagementService.autoMembershipDirty(false);
      await this.dataManagementService.setInteractive();
    } finally {
      this.busyService.hide();
    }
  }

  public checkChanges(): void {
    this.exprHasntChanged = _.isEqual(this.sqlExpression?.Expression, this.lastSavedExpression);
    if (!this.exprHasntChanged) {
      this.dataManagementService.autoMembershipDirty(true);
    } else if (this.cdrsHaventChanged && this.exprHasntChanged) {
      this.dataManagementService.autoMembershipDirty(false);
    }
  }

  public checkCDRs(): void {
    this.cdrsHaventChanged = this.cdrList
      .map((cdr, index) => {
        return cdr.column.GetValue() === this.lastSavedCDRs[index];
      })
      .every((isTrue) => isTrue);
    if (!this.cdrsHaventChanged) {
      this.dataManagementService.autoMembershipDirty(true);
    } else if (this.cdrsHaventChanged && this.exprHasntChanged) {
      this.dataManagementService.autoMembershipDirty(false);
    }
  }

  public isConditionInvalid(): boolean {
    return (
      (this.sqlExpression?.Expression?.Expressions?.length ?? 0) === 0 ||
      isExpressionInvalid(this.sqlExpression ?? {}) ||
      !this.hasValuesSet(this.sqlExpression?.Expression)
    );
  }

  private async loadDynamicRole(initialLoading = true): Promise<void> {
    try {
      this.busy = true;
      if (this.uidDynamicGroup) {
        const data = await this.apiService.typedClient.PortalDynamicgroupInteractive.Get(this.uidDynamicGroup);

        this.dynamicGroup = data.Data[0];
        if (initialLoading) {
          this.sqlExpression = data.extendedData?.Expressions?.[0];
          // Set "" to undefined so the cdr and data dirty states make sense
          this.sqlExpression?.Expression?.Expressions?.map((exp) => {
            if (exp.Value === '') {
              exp.Value = undefined;
            }
          });
          // Sometimes the logOp is not set. Initalize it here
          if (
            !this.sqlExpression?.IsUnsupported &&
            this.sqlExpression?.Expression != null &&
            !this.sqlExpression?.Expression?.LogOperator
          ) {
            this.sqlExpression.Expression.LogOperator = LogOp.AND;
          }
        }
        this.cdrList = this.canEdit
          ? [new BaseCdr(this.dynamicGroup.UID_DialogSchedule.Column), new BaseCdr(this.dynamicGroup.IsCalculateImmediately.Column)]
          : [
              new BaseReadonlyCdr(this.dynamicGroup.UID_DialogSchedule.Column),
              new BaseReadonlyCdr(this.dynamicGroup.IsCalculateImmediately.Column),
            ];
      }
    } finally {
      this.busy = false;
    }
  }

  private hasValuesSet(sqlExpression: SqlExpression | undefined, checkCurrent: boolean = false): boolean {
    const current =
      !checkCurrent ||
      (sqlExpression?.Value != null && (Object.keys(sqlExpression.Value).length > 0 || typeof sqlExpression.Value === 'boolean'));

    if (!!sqlExpression?.Expressions?.length) {
      return current && sqlExpression.Expressions.every((elem) => this.hasValuesSet(elem, true));
    }

    return current;
  }

  LdsUnsupportedExpression = '#LDS#You cannot edit these automatic memberships conditions in the Web Portal.';
  LdsNoDynamicRole =
    '#LDS#Currently, no identities automatically become members through a dynamic role. You can create a dynamic role through which identities automatically become members.';
  LdsWizardInfo = '#LDS#Identities automatically become members through this dynamic role if they meet the following conditions.';
}
